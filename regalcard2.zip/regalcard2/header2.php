<?php 
/**
 * RegalCard
 * @author angel zambrana
 * @owner Fundacio moli de puigvert
 * @date october 2015
 */
?>

<div class="col-md-8 col-md-offset-2 col-xs-10 col-xs-offset-1 col-sm-8 col-sm-offset-2">
<div class="alert alert-info" role="alert" align="center">
		<h1>
		<a href="javascript:window.history.back();">
		<span class="glyphicon glyphicon-arrow-left" aria-hidden="true"></span>
		</a> |----|
		<a href="<?php echo $url_link?>">
		<span class="glyphicon glyphicon-home" aria-hidden="true"></span></a>
		</h1>
		<h2>
		<?php echo $label_nameapp;?>
		</h2>
		<h3>
		<a href="<?php echo $url_link;?>/condictions.php">
		<?php echo $label_condictions;?></a>
		</h3>
	</div>
</div>
