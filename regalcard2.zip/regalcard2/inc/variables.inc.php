<?php

//GLOBALS VARIABLES
$pass='123456';

// include the url link
include 'link.inc.php';

// Don't connect database
$noconnect='No connecta';

//error in select, insert o update sql
$errorsearch='Consulta fallida';

//name of app
$label_nameapp='REGALCARD';
$label_regalcard='REGALCARD';
$label_fidelcard='FIDELCARD';
$label_nameapp_admin='ADMIN - REGALCARD - FIDELCARD';
$label_condictions='CONDICIONS';
$regalcard_noexist ='ERROR DADES';

//VARIABLES --> INDEX.PHP
//identificacion card
$label_check='COMPROVACIO';
$label_card_id='NUMERO';
$label_active ="ACTIVAR";
$label_card_new='NOVA';
$label_buy="COMPRAR";
$label_balance="SALDO";
$label_previous="ANTERIOR";
$label_autent='PASSWORD';

//VARIABLES --> active.php
$label_balance_init = 'SALDO INICIAL';
$label_date_begin = 'DATA INICI';
$label_date_end = 'DATA FINAL';
$label_email = 'EMAIL';
$label_email_2='REPETIR EMAIL';
$label_save='DESAR';

//VARIABLES --> active2.php
$label_email_gift = 'EMAIL REGAL';
$label_email_gift_2='REPETIR EMAIL REGAL';

//variables --> active3.php
$label_card_activate='TARGETA ACTIVADA';
$label_card_no_activate='TARGETA JA ACTIVADA';

//variables --> buy.php
$label_date_purchase='DATA COMPRA';
$label_total='IMPORT TOTAL';
$label_shop='BOTIGA';
$label_ticket='NUMERO TIQUET';
$label_cashier='NUMERO CAIXA';
$label_employer='EMPLEAT';
$label_card_no_valid='TARGETA ESGOTADA';

//variables --> show.php
$label_show = 'CODI QR';
?>
