<?php

//database route localhost
$host='localhost';
$user='';
$password='';
$database='';

?>
