<?php
//URL LINK
$url_link='http://regalcard2.fundaciomoli.org';
//$url_link='http://beta2.fundaciomoli.org';
//$url_link='http://localhost';
?>