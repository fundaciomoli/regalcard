<?php
/**
 * RegalCard
 * @author angel zambrana
 * @owner Fundacio moli de puigvert
 * @date october 2015
 */

 //include the header
 require_once $_SERVER['DOCUMENT_ROOT'].'/header.php';

?>
<body>
	<a id="catala"></a>
	<!-- Principal alert -->


	<div class="row">
		<div
			class="col-md-8 col-md-offset-2 col-xs-10 col-xs-offset-1 col-sm-8 col-sm-offset-2">
			<nav>
			<ul class="pager">
			 <li><a href="#castellano">CASTELLANO</a></li>
			 <li><a href="#botigues">ESTABLIMENTS</a></li>
			</ul>
			</nav>
			<h2 align="center">CATAL&Agrave;</h2>
				<h2 align="center"><a href="#catala">TOP</a></h2>
		<br>
		<a id="castellano"></a><h2 align="center">CASTELLANO</h2>
		<h2 align="center"><a href="#catala">TOP</a></h2>
		<br>
		<a id="botigues"></a><h2 align="center">ESTABLIMENTS</h2>
		<h2 align="center"><a href="#catala">TOP</a></h2>

		</div>

	</div>
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
	<script
		src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
	<!-- Include all compiled plugins (below), or include individual files as needed -->
	<script src="js/bootstrap.min.js"></script>
</body>
</html>
