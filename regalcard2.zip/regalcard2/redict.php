<?php
/**
 * RegalCard
 * @author angel zambrana
 * @owner Fundacio moli de puigvert
 * @date october 2015
 */
?>
<body>
<div class="col-md-8 col-md-offset-2 col-xs-10 col-xs-offset-1 col-sm-8 col-sm-offset-2">
<div class="alert alert-info" role="alert" align="center">
		<h3><?php echo $regalcard_noexist;?>
		</h3>
	</div>
</div>
</body>
</html>
